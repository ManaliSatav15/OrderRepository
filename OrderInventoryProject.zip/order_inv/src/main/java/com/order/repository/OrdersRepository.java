package com.order.repository;



import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.order.dto.OrderStoreDTO;
import com.order.model.Orders;

public interface OrdersRepository extends JpaRepository<Orders,Integer>{



	
	/* "SELECT COUNT(o) FROM Orders o WHERE o.orderStatus = :orderStatus" */
	@Query
	("SELECT COUNT(o) FROM Orders o WHERE o.orderStatus = ?1" )
	int getcountOfStatusByOrderStatus(String orderStatus);

	
	@Query
	("SELECT o.orderId, o.orderStatus, s.storeName, s.webAddress FROM Orders o join Stores s on o.stores.storeId = s.storeId WHERE  s.storeId = :storeId")
	List<Object[]> getOrderAndStores(int storeId);
	
	
	
	/*
	 * @Query
	 * ("SELECT NEW com.order.dto.OrderStoreDTO(s,s.Orders) from Stores s where s.Orders.orderId= :orderId"
	 * ) List<OrderStoreDTO> findByOrderIdOrderAndStore(@Param("orderId")int
	 * orderId);
	 * 
	 * 
	 * @Query
	 * ("SELECT o.orderid, o.orderstatus, s.storename, s.webaddress FROM Orders o JOIN Stores s ON o.orderId = s.orderId WHERE s.storename = :storeName"
	 * ) List<Orders> findByStoreId(@Param("storeId") int storeId);
	 */
	
	

	
}
