package com.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.order.dto.CustomerOrders;
import com.order.dto.ShipmentStatusCountCustomer;
import com.order.model.Customers;
import com.order.model.Shipments;

public interface CustomersRepository extends JpaRepository<Customers,Integer> {

	 @Query(value="select c from Customers c where c.email_address=?1")
		public List<Customers> getCustomersByEmail(String Email) ;

		@Query(value="select DISTINCT o from Orders o where o.customers.customer_id = ?1")
		public 	CustomerOrders getCustomerOrders(int customerId);

		@Query("SELECT s FROM Shipments s WHERE s.customers.customer_id = ?1 ")
		public List<Shipments> getCustomerShipments(@Param("Id") int customerId);
		
		@Query("SELECT new com.order.dto.ShipmentStatusCountCustomer(s.shipment_status,COUNT(s.customers))  FROM Shipments s WHERE s.shipment_status = ?1 GROUP BY s.shipment_status")
		public List<ShipmentStatusCountCustomer> getOrderCountByStatus(@Param("status") String shipmentStatus);
	
}
