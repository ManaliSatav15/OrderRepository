package com.order.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.exception.CustomerNotFoundException;
import com.order.exception.ProductNotFoundException;
import com.order.exception.StoreNotFoundException;
import com.order.model.Stores;

import com.order.repository.StoresRepository;

@Service
public class StoreServiceImpl implements StoreService{

	@Autowired
	StoresRepository storeRepository;
	
	

	@Override
	public List<Stores> getAllStores() {
		return storeRepository.findAll();
	}

	@Override
	public Stores createStores(Stores stores) {
		  return storeRepository.save(stores);
		
	}

	@Override
	public Stores getStoreById(int storeId) throws StoreNotFoundException {
		if(storeRepository.findById(storeId).isEmpty())
			throw new StoreNotFoundException("the Store with "+storeId+"does not extis");
		return storeRepository.findById(storeId).get();
	}

	
	
}
