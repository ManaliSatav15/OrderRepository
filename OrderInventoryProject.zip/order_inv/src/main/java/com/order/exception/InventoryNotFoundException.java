package com.order.exception;

public class InventoryNotFoundException extends Exception {
	String message;
	public InventoryNotFoundException(String message)
	{
		this.message=message;
	}
	public String  getMessage() {
		return this.message;
	}

}
