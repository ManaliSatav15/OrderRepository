package com.order.dto;

import java.util.List;
import com.order.model.Customers;
import com.order.model.Shipments;

public class CustomerShipment {
	private Customers customer;
	private List<Shipments> shipment;
	
	
	public CustomerShipment(Customers customer, List<Shipments> shipment) {
		super();
		this.customer = customer;
		this.shipment = shipment;
	}
	/*
	 * Getters and Setters
	 */
	public CustomerShipment() {
		super();
	}
	/**
	 * @return the customer
	 */
	public Customers getCustomer() {
		return customer;
	}
	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	/**
	 * @return the shipment
	 */
	public List<Shipments> getShipment() {
		return shipment;
	}
	/**
	 * @param shipment the shipment to set
	 */
	public void setShipment(List<Shipments> shipment) {
		this.shipment = shipment;
	}
	
	
}
