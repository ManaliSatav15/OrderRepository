package com.order.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.order.dto.CustomerOrders;
import com.order.dto.CustomerShipment;
import com.order.dto.ShipmentStatusCountCustomer;
import com.order.exception.CustomerNotFoundException;
import com.order.exception.NotFoundException;
import com.order.model.Customers;
import com.order.model.Shipments;
import com.order.repository.CustomersRepository;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomersRepository customersRepository;
	
	

	@Override
	public List<Customers> getAllCustomer() {
		return customersRepository.findAll();
	}

	@Override
	public Customers createCustomers(Customers customers) {
		 return customersRepository.save(customers);
		
	}
	
	
	 @Override
	    public String deleteCustomerById(int id) {
	    	String methodName = "deleteCustomer()";
		//	logger.info(methodName + "called");
			if (customersRepository.existsById(id)) {
				customersRepository.deleteById(id);
				return "Record deleted Successfully";
			}
			//throw exception
			return "Deletion Failed";
	    }
  

  

  

 	
	


    @Override

	public Customers getCustomersById(int Id) throws CustomerNotFoundException{

		if(customersRepository.findById(Id).isEmpty())
			throw new CustomerNotFoundException("The Channels with"+Id+"does not exists");
		return customersRepository.findById(Id).get();
	}
    
    @Override

	public Customers updateCustomer(Customers customer) throws CustomerNotFoundException {

		int customerId = customer.getCustomer_id();

		if (customersRepository.findById(customerId).isEmpty()) {

	        throw new CustomerNotFoundException("The employee with ID " + customerId + " does not exist");

	    }

	    return customersRepository.save(customer);

	}

	@Override
	public void save(Customers customer) {
		// TODO Auto-generated method stub
		customersRepository.save(customer);
		
	}
	
	public Customers updateByCustomerId(Customers customers) throws CustomerNotFoundException {

	    // Check if the department with the specified department number exists.

	    if (customersRepository.findById(customers.getCustomer_id()).isEmpty()) {

	        throw new CustomerNotFoundException("The customer with " + customers.getCustomer_id() + " doesn't exist");

	    }

	    return customersRepository.save(customers);

	}
	
	
	@Override
	public List<Customers> getCustomersByEmail(String Email) {
		 List<Customers> customersWithEmail = customersRepository.getCustomersByEmail(Email);
		    return customersWithEmail;
	}

	
	
	public CustomerOrders getCustomerOrders(@PathVariable("custid") int customerId) {
		
//		String methodName = "getCustomerOrders()";
//        logger.info(methodName + "called");
	
		CustomerOrders customerOrders = customersRepository.getCustomerOrders(customerId);

		if (customerOrders.getCustomer() == null && customerOrders.getOrder().isEmpty()) {
			throw new NotFoundException("No customer orders found for the provided customer ID: " + customerId);
		}
		return (customerOrders);
	}
		
		//Fetch shipment history for the respective customer by id 
		@Override
		public CustomerShipment getCustomerShipment(int customerId){
			String methodName = "getCustomerShipment()";
			//logger.info(methodName + "called");
			Customers customer =customersRepository.findById(customerId).orElse(null);
			List<Shipments> shipment = (List<Shipments>) customersRepository.getCustomerShipments(customerId);
			return new CustomerShipment(customer, shipment);
		}

		@Override
		public List<ShipmentStatusCountCustomer> getOrderCountByStatus(String shipmentStatus){
			String methodName = "getOrderCountByStatus()";
			//logger.info(methodName + "called");
			return customersRepository.getOrderCountByStatus(shipmentStatus);
		}

		@Override

	    public void deleteCustomer(int id) throws CustomerNotFoundException {

	        if (customersRepository.findById(id).isEmpty()) {

	            throw new CustomerNotFoundException("The shipper with ID " + id + " does not exist");

	        }

	        customersRepository.deleteById(id);

	    }

	
	
	
	
}
