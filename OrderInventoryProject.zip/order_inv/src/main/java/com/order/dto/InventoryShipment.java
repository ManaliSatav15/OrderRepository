package com.order.dto;

import com.order.model.Inventory;
import com.order.model.Shipments;

public class InventoryShipment {
	private Shipments shipment;
	private Inventory inventory;
	/**
	 * @param shipment
	 * @param inventory
	 */
	public InventoryShipment(Shipments shipment, Inventory inventory) {
		super();
		this.shipment = shipment;
		this.inventory = inventory;
	}
	/**
	 * Getters and Setters
	 */
	public InventoryShipment() {
		super();
	}
	/**
	 * @return the shipment
	 */
	public Shipments getShipment() {
		return shipment;
	}
	/**
	 * @param shipment the shipment to set
	 */
	public void setShipment(Shipments shipment) {
		this.shipment = shipment;
	}
	/**
	 * @return the inventory
	 */
	public Inventory getInventory() {
		return inventory;
	}
	/**
	 * @param inventory the inventory to set
	 */
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	
}
