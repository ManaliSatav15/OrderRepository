package com.order.services;

import java.util.List;

import com.order.exception.StoreNotFoundException;

import com.order.model.Stores;


public interface StoreService {

	
	List<Stores> getAllStores();
	public Stores createStores(Stores stores);
	/*
	 * Stores updateStore(Stores stores) throws StoreNotFoundException; void
	 * deleteStore(int storeId) throws StoreNotFoundException; 
	 */ 
	 Stores getStoreById(int storeId) throws StoreNotFoundException;
	 

    

}