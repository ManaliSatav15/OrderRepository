package com.order.controller;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.order.repository.InventoryRepository;
import com.order.dto.InventoryProductCustomerStore;
import com.order.dto.InventoryProductStoreShipmentStatusSum;
import com.order.dto.InventoryShipment;
import com.order.dto.InventoryStoreProductOrderStatus;
import com.order.dto.ShipmentStatusSoldProducts;
import com.order.model.Inventory;
//import com.order.exceptions.InvaliddataException;
//import com.order.exceptions.NotFoundException;
import com.order.services.InventoryServiceImpl;
//import com.order.utility.GlobalLogger;




@RestController
@RequestMapping("/api/v1/inventory")
public class InventoryController {
	
	//private Logger logger = GlobalLogger.getLogger(CustomerController.class);

	/**
	 *  @Autowired is used for automatic dependency injection in Spring Boot.
	 *  It allows spring to automatically wire beans & dependencies.
	 */

	@Autowired
	private InventoryServiceImpl inventoryServices;

	/**
	 * @RestController defines RESTful controller in SpringBoot.
	 * It combines @controller & @ResponseBody.These two annotations indicates that the returned 
	 * @RequestMapping used to map HTTP requests to specific handler method in controller.
	 * @return
	 */
	//good
	@GetMapping("/all")
	public ResponseEntity<List<Inventory>> getAllInventory() {
		
		String methodName = "getAllInventory()";
      //  logger.info(methodName + "called");
		
		List<Inventory> inventoryList = inventoryServices.getAllInventory();

		if (inventoryList.isEmpty()) {
			//throw new NotFoundException("No inventory items found");
		}
		return ResponseEntity.ok(inventoryList);
	}

	/**
	 * Handles the GET request to get ProductCustomerStoreByOrderId.
	 * @param orderId
	 * @return
	 */
	//good
	@GetMapping("/orderid/{id}")
	public ResponseEntity<InventoryProductCustomerStore> getProductCustomerStoreByOrderId(
			@PathVariable("id") int orderId) {

		String methodName = "getProductCustomerStoreByOrderId()";
      //  logger.info(methodName + "called");
        
		InventoryProductCustomerStore result = inventoryServices.getProductCustomerStoreByOrderId(orderId);

		if (result == null) {
			//throw new InvaliddataException(	"No inventory product customer store found for the provided order ID: " + orderId);
		}

		return ResponseEntity.ok(result);
	}


	/**
	 * Handles the GET request to get InventoryDetailsByOrderId.
	 * @param orderId
	 * @return
	 */
	//good
	@GetMapping("/{orderid}/details")
	public ResponseEntity<List<InventoryProductStoreShipmentStatusSum>> getInventoryDetailsByOrderId(@PathVariable("orderid") int orderId) {
		String methodName = "getInventoryDetailsByOrderId()";
      //  logger.info(methodName + "called");
		
		List<InventoryProductStoreShipmentStatusSum> result = inventoryServices.getInventoryDetailsByOrderId(orderId);

		if (result.isEmpty()) {
			//throw new NotFoundException("No inventory details found for the provided order ID: " + orderId);
		}

		return ResponseEntity.ok(result);
	}

	/**
	 * Handles the get request to get ProductOrderStatusByStoreId.
	 * @param storeId
	 * @return
	 */
	//not good
	@GetMapping("/store/{storeid}")
	public ResponseEntity<InventoryStoreProductOrderStatus> getProductOrderStatusByStoreId(@PathVariable("storeid") int storeId) {
		String methodName = "getProductOrderStatusByStoreId()";
      //  logger.info(methodName + "called");
		
		InventoryStoreProductOrderStatus result = inventoryServices.getProductOrderStatusByStoreId(storeId);

		if (result == null) {
		//	throw new NotFoundException("No product, order, or status details found for the provided store ID: " + storeId);
		}

		return new ResponseEntity<InventoryStoreProductOrderStatus>( result,HttpStatus.OK);
	}

	/**
	 * Handles the GET request to get InventoryShipmentById.
	 * @return
	 */
	
	//good
	@GetMapping("/{shipmentid}")
	public ResponseEntity<List<InventoryShipment>> getInventoryShipmentById() {
		String methodName = "getInventoryShipmentById()";
       // logger.info(methodName + "called");
		
		List<InventoryShipment> inventoryShipments = inventoryServices.getInventoryShipmentById();

		if (inventoryShipments.isEmpty()) {
			//throw new NotFoundException("No inventory shipment details found");
		}

		return new ResponseEntity<List<InventoryShipment>>(inventoryShipments,HttpStatus.OK);
	}

	/**
	 * Handles the GET request to get CountOfSoldProductByShipmentStatus
	 * @return
	 */
	
	//good
	@GetMapping("/shipment/soldproducts")
	public ShipmentStatusSoldProducts getCountOfSoldProductsByShipmentStatus() {
		String methodName = "getCountOfSoldProductsByShipmentStatus()";
       // logger.info(methodName + "called");
		
		return inventoryServices.getCountOfSoldProductsByShipmentStatus();
	}
}