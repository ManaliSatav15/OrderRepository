package com.order.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.dto.OrderStoreDTO;
import com.order.exception.OrderNotFoundException;
import com.order.model.Orders;
import com.order.repository.OrdersRepository;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrdersRepository ordersRepository;
	
	@Override
	public Orders getOrderById(int orderId) throws OrderNotFoundException {
		if(ordersRepository.findById(orderId).isEmpty())
			throw new OrderNotFoundException("the Orders with does not exists",orderId);
		return ordersRepository.findById(orderId).get();
		
	}
	
	@Override
	public List<Orders> getAllOrders() {
		return ordersRepository.findAll();
	}

	@Override

	public Orders createOrders(Orders orders) {

		  return ordersRepository.save(orders);

		

	}

	
	  @Override public Orders updateOrders(Orders orders) throws OrderNotFoundException {
	  if(ordersRepository.findById(orders.getOrderId()).isEmpty()) 
		  throw new OrderNotFoundException("the Orders with  does not exists" ,orders.getOrderId()); 
	  return ordersRepository.save(orders); }
	 

	@Override
	public String deleteOrders(int orderId) throws OrderNotFoundException {
	    Optional<Orders> orderOptional = ordersRepository.findById(orderId);

	    if (orderOptional.isEmpty()) {
	        throw new OrderNotFoundException("The order with ID " + orderId + " does not exist");
	    }
	    ordersRepository.delete(orderOptional.get());

	    return "Order with ID " + orderId + " has been deleted successfully.";
	}


	@Override
	public int getcountOfStatusByOrderStatus(String orderStatus) {
		return ordersRepository.getcountOfStatusByOrderStatus(orderStatus);
	}

	
	/*
	 * @Override public String updateOrders(Orders orders) throws
	 * OrderNotFoundException { if
	 * (ordersRepository.existsById(orders.getOrderId())) {
	 * ordersRepository.save(orders); return "Order with ID " + orders.getOrderId()
	 * + " has been updated successfully."; } else { throw new
	 * OrderNotFoundException("The order with ID " + orders.getOrderId() +
	 * " does not exist"); } }
	 */



	@Override
	public List<OrderStoreDTO> getOrderAndStores(int storeId) {
	
		return ordersRepository.getOrderAndStores(storeId)
				.stream()
				.map(m->new OrderStoreDTO((int)(m[0]),String.valueOf(m[1]),String.valueOf(m[2]),String.valueOf(m[3])))
				.collect(Collectors.toList());
	}



	
	

	
}
