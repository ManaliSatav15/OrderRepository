package com.order.services;

import java.util.List;

import com.order.dto.InventoryProductCustomerStore;
import com.order.dto.InventoryProductStoreShipmentStatusSum;
import com.order.dto.InventoryShipment;
import com.order.dto.InventoryStoreProductOrderStatus;
import com.order.dto.ShipmentStatusSoldProducts;
import com.order.exception.InventoryNotFoundException;
import com.order.model.Inventory;


public interface InventoryService {

	Inventory getInventoryById(int inventoryId) throws InventoryNotFoundException;
	List<Inventory> getAllInventory();
	void createInventory(Inventory inventory);
	Inventory updateInventory(Inventory inventory) throws InventoryNotFoundException;
	void deleteInventory(int inventoryId) throws InventoryNotFoundException;
		
	
	InventoryProductCustomerStore getProductCustomerStoreByOrderId(int orderId);

	List<InventoryProductStoreShipmentStatusSum> getInventoryDetailsByOrderId(int orderId);

	InventoryStoreProductOrderStatus getProductOrderStatusByStoreId(int storeId);

	List<InventoryShipment> getInventoryShipmentById();

	ShipmentStatusSoldProducts getCountOfSoldProductsByShipmentStatus();

	//Shipment<StatusSoldProducts> getCountOfSoldProductsByShipmentStatus();

    

}