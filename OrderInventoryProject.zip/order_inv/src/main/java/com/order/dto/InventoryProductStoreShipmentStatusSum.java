package com.order.dto;

import java.math.BigDecimal;

import com.order.model.Products;
import com.order.model.*;

public class InventoryProductStoreShipmentStatusSum {
	private Products product;
	private Stores store;
	private String shipmentStatus;
	private double total;

	/**
	 * @param product
	 * @param store
	 * @param shipmentStatus
	 * @param total
	 */
	public InventoryProductStoreShipmentStatusSum(Products product, Stores store, String shipmentStatus, double total) {
		super();
		this.product = product;
		this.store = store;
		this.shipmentStatus = shipmentStatus;
		this.total = total;
	}

	/**
	 * Getters and Setters
	 */
	public InventoryProductStoreShipmentStatusSum() {
		super();
	}

	/**
	 * @return the product
	 */
	public Products getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Products product) {
		this.product = product;
	}

	/**
	 * @return the store
	 */
	public Stores getStore() {
		return store;
	}

	/**
	 * @param store the store to set
	 */
	public void setStore(Stores store) {
		this.store = store;
	}

	/**
	 * @return the shipmentStatus
	 */
	public String getShipmentStatus() {
		return shipmentStatus;
	}

	/**
	 * @param shipmentStatus the shipmentStatus to set
	 */
	public void setShipmentStatus(String shipmentStatus) {
		this.shipmentStatus = shipmentStatus;
	}

	/**
	 * @return the total
	 */
	public double getTotal() {
		return total;
	}

	/**
	 * @param total the total to set
	 */
	public void setTotal(double total) {
		this.total = total;
	}

}
