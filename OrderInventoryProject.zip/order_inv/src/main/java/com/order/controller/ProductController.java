package com.order.controller;

import java.math.BigDecimal;

import org.springframework.data.domain.Sort;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.order.exception.CustomerNotFoundException;
import com.order.exception.OrderNotFoundException;
import com.order.exception.ProductNotFoundException;
import com.order.exception.StoreNotFoundException;
import com.order.model.Customers;
import com.order.model.Orders;
import com.order.model.Products;
import com.order.model.Stores;
import com.order.repository.ProductsRepository;
import com.order.services.ProductService;



@Controller
@RequestMapping("/api/v1/products")
public class ProductController {
	
    @Autowired
    ProductService productService;
	private ProductController prod;
    

	  @GetMapping("/all")
	  public ResponseEntity<List<Products>> getAllProducts(){
		return new ResponseEntity<List<Products>>(productService.getAllProducts(),HttpStatus.OK);
		  
	  }
	  
	  @GetMapping("/{productName}")
	  public ResponseEntity<List<Products>> getProductByName(@PathVariable String productName) throws ProductNotFoundException{
		return new ResponseEntity<List<Products>>(productService.getProductByName(productName),HttpStatus.OK);
		  
	  }
	  
		
		  @PostMapping("/add") public ResponseEntity<Products>
		  createProducts(@RequestBody Products products) throws
		  ProductNotFoundException {
		  
		  
		  Products productAdded=productService.createProducts(products);
		  
		  return new ResponseEntity<Products>(productAdded , HttpStatus.CREATED);
		  }
		  
		  
		  @DeleteMapping("/delete/{id}")
		    public ResponseEntity<String> deleteProductById(@PathVariable("id") int id) {
		        String resultMessage = productService.deleteProductById(id);

		        if ("Record deleted Successfully".equals(resultMessage)) {
		            // Return a success response with a 200 OK status
		            return new ResponseEntity<>(resultMessage, HttpStatus.OK);
		        } else {
		            // Return an error response with a 404 Not Found status
		            return new ResponseEntity<>(resultMessage, HttpStatus.NOT_FOUND);
		        }
		    }
		 
		  @PutMapping("/update")
		    public ResponseEntity<String> updateproduct(@RequestBody Products product) {
		        // Call the service method to update the product
		        String resultMessage = productService.updateProduct(product);

		        if ("Record Updated Successfully".equals(resultMessage)) {
		            // Return a success response with a 200 OK status
		            return new ResponseEntity<>(resultMessage, HttpStatus.OK);
		        } else {
		            // Return an error response with a 404 Not Found status or other appropriate status
		            return new ResponseEntity<>(resultMessage, HttpStatus.NOT_FOUND);
		        }
		    }
	  
	  
		  
			
			
		  @GetMapping("/unitprice")
		  public ResponseEntity<List<Products>> getProductsByUnitPriceRange(@RequestParam("min") BigDecimal min,
					@RequestParam("max") BigDecimal max) throws Exception{
			  List<Products> products = productService.getProductsByUnitPriceRange(min, max);
			  if (products.isEmpty()) {
					throw new Exception(" product Price Not found within the specified unit price range");
				}

				return new ResponseEntity<List<Products>>(products, HttpStatus.OK);
			}
		  
		  
		  @GetMapping("/sort")
			public ResponseEntity<List<Products>> getSortedProductsByField(@RequestParam("field") String field) throws Exception {
			  Sort sort = Sort.by(field);

				List<Products> sortedProducts = productService.getSortedProductsByField(sort);

				if (sortedProducts.isEmpty()) {
					throw new Exception("No products found for sorting field: " + field);
				}
				return ResponseEntity.ok(sortedProducts);
			}

		  }
	  
	  
	  
    


