package com.order.exception;

public class CustomerNotFoundException extends Exception {
	String message;
	public CustomerNotFoundException(String message)
	{
		this.message=message;
	}
	public String  getMessage() {
		return this.message;
	}

}
