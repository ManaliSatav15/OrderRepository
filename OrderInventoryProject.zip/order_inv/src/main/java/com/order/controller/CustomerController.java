package com.order.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.order.dto.CustomerShipment;
import com.order.dto.ShipmentStatusCountCustomer;
import com.order.exception.CustomerNotFoundException;
import com.order.exception.InvalidDataException;
import com.order.exception.NotFoundException;
import com.order.model.Customers;
import com.order.model.Orders;
import com.order.services.CustomerService;



@Controller
@RequestMapping("/api/v1/customer")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	 @GetMapping("/")
	  public ResponseEntity<List<Customers>> getAllOrders(){
		return new ResponseEntity<List<Customers>>(customerService.getAllCustomer(),HttpStatus.OK);
		  
	 }
	 
	 @PostMapping("/add")

		public ResponseEntity<String> createCustomers(@RequestBody Customers customer) {

			customerService.createCustomers(customer);

			return new ResponseEntity<>("Record Added Successfully!!", HttpStatus.OK);

		}

	

	  

	 @DeleteMapping("/delete/{id}")
	    public ResponseEntity<String> deleteCustomerById(@PathVariable("id") int id) {
	        String resultMessage = customerService.deleteCustomerById(id);

	        if ("Record deleted Successfully".equals(resultMessage)) {
	            // Return a success response with a 200 OK status
	            return new ResponseEntity<>(resultMessage, HttpStatus.OK);
	        } else {
	            // Return an error response with a 404 Not Found status
	            return new ResponseEntity<>(resultMessage, HttpStatus.NOT_FOUND);
	        }
	    }

	 @PutMapping("/{id}")

	     public ResponseEntity<Customers> updateCustomer(@PathVariable int id, @RequestBody Customers updatedCustomer) throws CustomerNotFoundException {

	         updatedCustomer.setCustomer_id(id);

			 Customers customer = customerService.updateCustomer(updatedCustomer);

			 return ResponseEntity.ok(customer);

	     }
	 
	 
	 @GetMapping("/{email}")
	    public ResponseEntity<List<Customers>> getCustomersByEmail( @PathVariable ("email") String email) {
	        List<Customers> customers = customerService.getCustomersByEmail(email);

	        if (customers.isEmpty()) {
	            // Return 404 Not Found if no customers were found with the provided email
	            //return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        	throw new NotFoundException("No Customers With Specific Email");
	        } else {
	            // Return the list of customers with a 200 OK code
	            return new ResponseEntity<>(customers, HttpStatus.OK);
	        }
	    }
	 
	 @DeleteMapping("/del/{id}")

	    public ResponseEntity<Void> deleteCustomer(@PathVariable("id") int id) throws CustomerNotFoundException {

		 customerService.deleteCustomer(id);

	        return new ResponseEntity<>(HttpStatus.OK);

	    }

	 
	 
//	   @GetMapping("/get/{id}")
//	    public ResponseEntity<?> getCustomerById(@PathVariable("id") int id) {
//	        Optional<Customers> optionalCustomer = customerService.getCustomersById(id);
//
//	        if (optionalCustomer.isPresent()) {
//	            // Return the customer with a 200 OK status
//	            return new ResponseEntity<>(optionalCustomer.get(), HttpStatus.OK);
//	        } else {
//	            // Return a 404 Not Found response if the customer does not exist
//	           // return new ResponseEntity<>("Customer not found", HttpStatus.NOT_FOUND);
//	        throw new NotFoundException("Customer with" + id + "does not exist");
//	        }
//	    }
//	  
	   
	   
	    //not good
	    @GetMapping("/{customerId}/orders")
	    public ResponseEntity<List<Orders>> getOrdersByCustomerId(@PathVariable int customerId) {
	        List<Orders> orders = (List<Orders>) customerService.getCustomerOrders(customerId);

	        if (!orders.isEmpty()) {
	            return new ResponseEntity<>(orders, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }
	    
	    
	    
		@GetMapping("/{custid}/shipment")
		public ResponseEntity<CustomerShipment> getCustomerShipment(@PathVariable("custid") int customerId) {
			
			//String methodName = "getCustomerShipment()";
	       // logger.info(methodName + "called");
			
			CustomerShipment customerShipment = customerService.getCustomerShipment(customerId);

			if (customerShipment.getCustomer() == null && customerShipment.getShipment().isEmpty()) {
			    throw new NotFoundException("No customer shipment found for the provided customer ID: " + customerId);
			}
			return ResponseEntity.ok(customerShipment);
		}
		
		
		
		@GetMapping("/{status}/shipmentstat")
		public ResponseEntity<List<ShipmentStatusCountCustomer>> getOrderCountByStatus(
				@PathVariable("status") String status) {
			
			String methodName = "getOrderCountByStatus()";
	    //    logger.info(methodName + "called");
			
			List<ShipmentStatusCountCustomer> shipmentStatusCount = customerService.getOrderCountByStatus(status);

			if (shipmentStatusCount.isEmpty()) {
				throw new InvalidDataException("No shipment status count found for status: " + status);
				//return new ResponseEntity<>(HttpStatus.OK);
			}
			return new ResponseEntity<List<ShipmentStatusCountCustomer>>(shipmentStatusCount, HttpStatus.OK);
		}
	 	   
}