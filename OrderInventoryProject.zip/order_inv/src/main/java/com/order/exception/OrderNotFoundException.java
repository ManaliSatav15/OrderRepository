package com.order.exception;

public class OrderNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;
	String message;
	public OrderNotFoundException(String message)
	{
		this.message=message;
	}
	public OrderNotFoundException(String string, int orderId) {
		// TODO Auto-generated constructor stub
	}
	public String  getMessage() {
		return this.message;
	}

}
